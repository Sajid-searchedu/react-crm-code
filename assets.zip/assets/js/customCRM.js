//------sidebartoggle---------

jQuery(document).ready(function($) {
   var bsDefaults = {
         offset: false,
         overlay: true,
         width: '210px'
      },
      bsMain = $('.bs-offset-main'),
      bsOverlay = $('.bs-canvas-overlay');

   $('[data-toggle="canvas"][aria-expanded="false"]').on('click', function() {
      var canvas = $(this).data('target'),
         opts = $.extend({}, bsDefaults, $(canvas).data()),
         prop = $(canvas).hasClass('bs-canvas-right') ? 'margin-right' : 'margin-left';

      if (opts.width === '100%')
         opts.offset = false;
      
      $(canvas).css('width', opts.width);
      if (opts.offset && bsMain.length)
         bsMain.css(prop, opts.width);

      $(canvas + ' .bs-canvas-close').attr('aria-expanded', "true");
      $('[data-toggle="canvas"][data-target="' + canvas + '"]').attr('aria-expanded', "true");
      if (opts.overlay && bsOverlay.length)
         bsOverlay.addClass('show');
      return false;
   });

   $('.bs-canvas-close, .bs-canvas-overlay').on('click', function() {
      var canvas, aria;
      if ($(this).hasClass('bs-canvas-close')) {
         canvas = $(this).closest('.bs-canvas');
         aria = $(this).add($('[data-toggle="canvas"][data-target="#' + canvas.attr('id') + '"]'));
         if (bsMain.length)
            bsMain.css(($(canvas).hasClass('bs-canvas-right') ? 'margin-right' : 'margin-left'), '');
      } else {
         canvas = $('.bs-canvas');
         aria = $('.bs-canvas-close, [data-toggle="canvas"]');
         if (bsMain.length)
            bsMain.css({
               'margin-left': '',
               'margin-right': ''
            });
      }
      canvas.css('width', '');
      aria.attr('aria-expanded', "false");
      if (bsOverlay.length)
         bsOverlay.removeClass('show');
      return false;
   });
});


//for sidebar close btn  javascript-->

  $('.openNav').click(function(){
$('.bs-canvas-close , .nav-img-icon span').show();
});
  $('.bs-canvas-close , .bs-canvas-overlay').click(function(){
$('.bs-canvas-close , .nav-img-icon span').hide('slow');
});



//<!-- for sidebar Navbar for Mobile View javascript-->

   if (window.matchMedia("(max-width: 500px)").matches) 
        {
           jQuery(document).ready(function($) {
   var bsDefaults = {
         offset: false,
         overlay: true,
         width: '200px'
      },
      bsMain = $('.bs-offset-main'),
      bsOverlay = $('.bs-canvas-overlay');

   $('[data-toggle="canvas"][aria-expanded="false"]').on('click', function() {
      var canvas = $(this).data('target'),
         opts = $.extend({}, bsDefaults, $(canvas).data()),
         prop = $(canvas).hasClass('bs-canvas-right') ? 'margin-right' : 'margin-left';

      if (opts.width === '100%')
         opts.offset = false;
      
      $(canvas).css('width', opts.width);
      if (opts.offset && bsMain.length)
         bsMain.css(prop, opts.width);

      $(canvas + ' .bs-canvas-close').attr('aria-expanded', "true");
      $('[data-toggle="canvas"][data-target="' + canvas + '"]').attr('aria-expanded', "true");
      if (opts.overlay && bsOverlay.length)
         bsOverlay.addClass('show');
      return false;
   });

   $('.bs-canvas-close, .bs-canvas-overlay').on('click', function() {
      var canvas, aria;
      if ($(this).hasClass('bs-canvas-close')) {
         canvas = $(this).closest('.bs-canvas');
         aria = $(this).add($('[data-toggle="canvas"][data-target="#' + canvas.attr('id') + '"]'));
         if (bsMain.length)
            bsMain.css(($(canvas).hasClass('bs-canvas-right') ? 'margin-right' : 'margin-left'), '');
      } else {
         canvas = $('.bs-canvas');
         aria = $('.bs-canvas-close, [data-toggle="canvas"]');
         if (bsMain.length)
            bsMain.css({
               'margin-left': '',
               'margin-right': ''
            });
      }
      canvas.css('width', '');
      aria.attr('aria-expanded', "false");
      if (bsOverlay.length)
         bsOverlay.removeClass('show');
      return false;
   });
});

        }


//<!-- for searchbar in user javascript-->
function openSearch() {
  document.getElementById("mySearch").style.display = "block";
}

function closeSearch() {
  document.getElementById("mySearch").style.display = "none";
}



//<!-- for contact-right-side  javascript-->

  $('.create-contact').click(function(){
     $(".contact-right-side").addClass('contacts-slide');

});
  $('.right-panle-close').click(function(){
     $(".contact-right-side").removeClass('contacts-slide');

});





//<!-- for CreatContact overlay  javascript-->
function openCreatContact() {
  document.getElementById("CreatContact").style.width = "100%";
}

function closeCreatContact() {
  document.getElementById("CreatContact").style.width = "0%";
}


//<!-- for add remove input fields  javascript-->
    $(document).ready(function(){
    $('.second-btn-plus').click(function() {
      $('.third-input').show("slide");
      $('.second-btn-plus').hide();
    });
     $('.third-btn-minus').click(function() {
      $('.third-input').hide("slide");
       $('.second-btn-plus').show();
    });
     $('.second-btn-minus').click(function() {
      $('.Second-input').hide("slide");
       $('.second-btn-plus').show();
       $('.first-btn-plus').show();

    });
      $('.first-btn-plus').click(function() {
      $('.Second-input').show("slide");
       $('.first-btn-plus').hide();
    });
});

     $(document).ready(function(){
    $('.second-btn-plus-email').click(function() {
      $('.third-input-email').show("slide");
      $('.second-btn-plus-email').hide();
    });
     $('.third-btn-minus-email').click(function() {
      $('.third-input-email').hide("slide");
       $('.second-btn-plus-email').show();
    });
     $('.second-btn-minus-email').click(function() {
      $('.Second-input-email').hide("slide");
       $('.second-btn-plus-email').show();
       $('.first-btn-plus-email').show();

    });
      $('.first-btn-plus-email').click(function() {
      $('.Second-input-email').show("slide");
       $('.first-btn-plus-email').hide();
    });
});


// <!-- help toggle javascript -->
  $(document).ready(function(){
    $('.se-help').click( function(){
      $('.help-message').toggle('slow');
    });
  });



//<!-- Mobile View filter button javascript -->
  $(document).ready(function(){
    $('.mob-nav-open').click( function(){
      $('.filter-body-mob').toggle('slow');
    });
  });


// <!-- mobile-view-user toggle javascript -->
 $(document).ready(function(){
 $('.show-user-view').click( function(){
 $('.user-mob-view').toggle();
 });
});


// <!-- for Creat Deal javascript-->
   function openCreatDeal() {
  document.getElementById("Add-deals-popup").style.width = "100%";
}
function closeCreatDeal() {
  document.getElementById("Add-deals-popup").style.width = "0%";
}




// <!-- current-Page-url-active -->

  $(document).ready(function() {

 // Get current page URL
 var url = window.location.href;

 // remove # from URL
 url = url.substring(0, (url.indexOf("#") == -1) ? url.length : url.indexOf("#"));

 // remove parameters from URL
 url = url.substring(0, (url.indexOf("?") == -1) ? url.length : url.indexOf("?"));

 // select file name
 url = url.substr(url.lastIndexOf("/") + 1);
 
 // If file name not avilable
 if(url == ''){
 url = 'index.html';
 }
 
 // Loop all menu items
 $('.menu li').each(function(){

  // select href
  var href = $(this).find('a').attr('href');
 
  // Check filename
  if(url == href){

   // Add active class
   
   $(this).addClass('active');

   // Add ative parent class
   $(this).parent().addClass('activeparent')
  }
 });

});


// <!--prefrence-show-menu-dropdown------------->

  $(document).ready(function(){
  $('.click-show-menu').each(function() {
    var $dropdown = $(this);

    $(".drop-menu", $dropdown).click(function(e) {
      e.preventDefault();
      $div = $(".menu", $dropdown);
      $div.toggle('slow');
      $(".menu").not($div).hide('slow');
      return false;
    });
});
});

// <!-- Mobile View-mob-preferences-filter button javascript -->
  $(document).ready(function(){
    $('.mob-nav-open').click( function(){
      $('.mob-preferences').toggle('slow');
    });
  });
